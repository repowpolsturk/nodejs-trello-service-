const Task = require('../models/task');
const taskController = {
  async getAllTasks(req, res){
  },
  async getTaskById(req, res){
  },
  async createTask(req, res){
  },
  async updateTask(req, res){
  },
  async deleteTask(req, res){
  }
};
module.exports = taskController;