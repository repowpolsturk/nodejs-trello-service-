const pool = require('../db');
const setUpController = {
  async setUpDatabase(req, res) {
    try {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS users (
          id SERIAL PRIMARY KEY,
          name VARCHAR(255) NOT NULL,
          email VARCHAR(255) UNIQUE NOT NULL,
          password VARCHAR(255) NOT NULL
        );
        CREATE TABLE IF NOT EXISTS boards (
          id SERIAL PRIMARY KEY,
          title VARCHAR(255) NOT NULL
        );
        CREATE TABLE IF NOT EXISTS tasks (
          id SERIAL PRIMARY KEY,
          title VARCHAR(255) NOT NULL,
          "orders" INTEGER NOT NULL,
          description TEXT,
          "userId" INTEGER REFERENCES users(id) ON DELETE SET NULL,
          "boardId" INTEGER REFERENCES boards(id) ON DELETE CASCADE
        );
      `);
      res.status(200).json({ message: 'Databaza muvofaqiyatli sozlandi' });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
};
module.exports = setUpController;