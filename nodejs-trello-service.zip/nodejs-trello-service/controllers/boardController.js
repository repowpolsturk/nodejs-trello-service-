const Board = require('../models/board');
const boardController = {
  async getAllBoards(req, res){
  },
  async getBoardById(req, res){
  },
  async createBoard(req, res){
  },
  async updateBoard(req, res){
  },
  async deleteBoard(req, res){
  }
};
module.exports = boardController;