const User = require('../models/task');
const userController = {
  async getAllUsers(req, res){
  }, 
  async getUserById(req, res){
  }, 
  async updateUser(req, res){
  },
  async deleteUser(req, res){
  }
};
module.exports = userController;
