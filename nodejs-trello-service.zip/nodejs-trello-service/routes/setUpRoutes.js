const express = require('express');
const router = express.Router();
const setUpController = require('../controllers/setUpController');
router.post('/', setUpController.setUpDatabase);
module.exports = router;