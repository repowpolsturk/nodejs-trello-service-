const pool = require('../db');
const Board = {
  async create({ title }) {
    const result = await pool.query('INSERT INTO boards (title) VALUES ($1) RETURNING id, title', [title]);
    return result.rows[0];
  },
};
module.exports = Board;