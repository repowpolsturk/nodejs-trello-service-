const pool = require('../db');
const Task = {
  async create({ title, orders, description, userId, boardId}) {
    const result = await pool.query(
      'INSERT INTO tasks (title, "orders", description, "userId", "boardId") VALUES ($1, $2, $3, $4, $5) RETURNING id, title, "orders", description, "userId", "boardId",',
      [title, orders, description, userId, boardId]
    );
    return result.rows[0];
  },
};
module.exports = Task;