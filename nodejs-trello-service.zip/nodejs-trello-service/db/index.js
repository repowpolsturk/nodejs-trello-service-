const { Pool } = require('pg');
const pool = new Pool({
  connectionString: process.env.DATABSE_URL
});
pool.on('connect', () => {
  console.log('psql databazasiga ulandi');
});
module.exports = pool;