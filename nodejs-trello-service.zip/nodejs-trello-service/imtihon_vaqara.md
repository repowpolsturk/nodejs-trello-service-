Ushbu loyihani maqsadi sizning RESTfull xizmat yaratish. Sen PostgreSQL malumotlar bazasi bilan integratsiya bolgan to'liq CRUD (Create, Read, Update, Delete) operatsiyalarni amalga oshiradigan RESTfull API tuzishing kerak boladi.

### Imtihon Topshiriqlari:
1. **Resurslar va CRUD Operatsiyalar:**
    - Quyidagi resurslar bilan ishlovchi REST endpointlar yaratish:
    - `POST /setUp`  route ga murojat qilganda tablelar yo'q bo'lsa yaratilsin.
    - **Autentifikatsiya:**
        - Ro'yxatdan o'tish (`/register`) va kirish (`/login`) endpointlarini yarating:
            - `POST /register`:
                - Foydalanuvchi ro'yxatdan o'tishi uchun endpoint.
                - Ma'lumotlar bazasiga foydalanuvchini passwordini `bcrypt` bilan hash bilan saqlanadi va foydalanuvchi ma'lumotlarini qaytarish kerak! (javobdan parolni olib tashlash!).
        - `POST /login`:
            - Foydalanuvchi tizimga kirishi uchun endpoint.
            - Foydalanuvchini `login` va `parol` orqali tekshiriladi, agar ma'lumotlar to'g'ri bo'lsa, foydalanuvchi ma'lumotlarini qaytaradi (parolni javobdan olib tashlash).
    - **User (Foydalanuvchi)**:
        
        ```jsx
        { id, name, email, password }
        
        ```
        
        - `GET /users` - barcha foydalanuvchilarni olish (javobdan parolni olib tashlash).
        - `GET /users/:userId` - foydalanuvchini ID bo'yicha olish (javobdan parolni olib tashlash).
        - `PUT /users/:userId` - foydalanuvchini yangilash.
        - `DELETE /users/:userId` - foydalanuvchini o'chirish.
    - **Board (Doskalar)**:
        
        ```jsx
        { id, title }
        ```
        
        - `GET /boards` - barcha doskalarni olish.
        - `GET /boards/:boardId` - doskani ID bo'yicha olish.
        - `POST /boards` - doska yaratish.
        - `PUT /boards/:boardId` - doskani yangilash.
        - `DELETE /boards/:boardId` - doskani o'chirish.
    - **Task (Vazifalar)**:
        
        ```jsx
        {
          id,
          title,
          order,
          description,
          userId, 
          boardId
        }
        ```
        
        - `GET boards/:boardId/tasks` - barcha vazifalarni olish.
        - `GET boards/:boardId/tasks/:taskId` - vazifani ID bo'yicha olish.
        - `POST boards/:boardId/tasks` - vazifa yaratish.
        - `PUT boards/:boardId/tasks/:taskId` - vazifani yangilash.
        - `DELETE boards/:boardId/tasks/:taskId` - vazifani o'chirish.
        - 
2. **Qo'shimcha Talablar:**
    - **Board** o'chirilganda, uning barcha **Task**lari ham o'chirilishi kerak.
    - **User** o'chirilganda, uning barcha **Task**lari uchun `userId` `null`ga o'zgartirilishi kerak.
    - Endpointlar faqat   ma'lumotlar bazasi bilan ishlashligi kerak.
    - `application/json` formati so'rov va javoblar uchun ishlatilishi kerak.
    - Kodni bitta folder da saqlamang - ilova yaratish, *routerlar* (**controllers**) , **database** va shu loyiha mantiqiga oid kodlarni alohida folder ga ajrating.
    - Projectni ishga  tushirish uchun `npm run dev` buyrug'ini ishlating.
    - Xizmat 4000-portda listen qilish kerak.
3. **Ma'lumotlar Bazasi:**
    - `pg` moduli orqali PostgreSQLni Node.jsga ulash:
        - `pg` modulini o'rnating.
        - Bazaga yozishdan oldin userning passwordini `bcrypt` bilan hash qilib joylash kerak!.
        - Bazaga ulaning va CRUD operatsiyalarni amalga oshiring.
# `BONUS`

> Bonus faqatgina avvalgi tasklarni tugatganlar uchun agarda yakunlamagan bo'lsangiz avval tugating!. Yuqoridagi task yakunlagandan song bonusga otish mumkin va shundan keyin ball qoshiladi!.
> 

- Siz qoshilishi kerak deb bilagan functionni qoshing va `[BINASA.md](http://BINASA.md)` da shu haqida qisqacha tavsif qoldiring!.


### Baholash Mezoni:

## REST endpointlarining to'liq amalga oshirilishi:  40 ball

## Ma'lumotlar bazasi bilan integratsiya va CRUD operatsiyalari: 30 ball

## Kodni strukturalash va modullarga ajratish: 10 ball

## Autentifikatsiya endpointlarining ishlashi: 10 ball

## Kodning tozaligi (fileNomlari, class & function nomlari ): 10 ball

### Vaqt:

- Imtihon muddati: 4 soat

### Imtihon muvaffaqiyatli bo'lishi uchun yuqoridagi barcha talablarga rioya qilishingiz kerak. Omad