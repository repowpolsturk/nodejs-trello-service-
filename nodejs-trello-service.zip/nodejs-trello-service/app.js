require('dotenv').config();
const express = require('express');
const app = express();
const port = 4000;
app.use(express.json());
app.use('/auth', require('./routes/authRoutes'));
app.use('/users', require('./routes/userRoutes'));
app.use('/boards', require('./routes/boardRoutes'));
app.use('/boards/:boardId/tasks', require('./routes/taskRoutes'));
app.listen(port, () => {
  console.log(`Server ishga tushdi ${port}`);
});